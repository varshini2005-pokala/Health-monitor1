import { Menu, ArrowLeft, User, Bell, Settings } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { TabType } from "../types";

interface HeaderProps {
  onMenuClick: () => void;
  sidebarOpen: boolean;
  onLoginClick: () => void;
  onBack: () => void;
  onProfileClick: () => void;
  activeTab: TabType;
  userName: string;
}

export default function Header({ onMenuClick, sidebarOpen, onLoginClick, onBack, onProfileClick, activeTab, userName }: HeaderProps) {
  return (
    <header className="bg-white border-b border-slate-200 px-4 md:px-6 py-4 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onMenuClick}
          className="text-slate-600 hover:text-slate-900 hover:bg-slate-100"
        >
          <Menu className="w-5 h-5" />
        </Button>

        {activeTab !== "home" && activeTab !== "profile" && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="text-slate-600 hover:text-slate-900 hover:bg-slate-100"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        )}

        <h2 className="text-lg font-semibold text-slate-800 hidden md:block">
          {activeTab === "home" ? "Health Monitor" : 
           activeTab === "profile" ? "My Profile" :
           activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
        </h2>
      </div>

      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="text-slate-600 hover:text-slate-900">
          <Bell className="w-5 h-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-slate-600 hover:text-slate-900">
          <Settings className="w-5 h-5" />
        </Button>
        
        <div className="h-6 w-px bg-slate-200 mx-1" />
        
        {/* Profile Button - Now clickable to navigate to profile */}
        <Button 
          variant="ghost" 
          className="flex items-center gap-2 text-slate-700 hover:text-slate-900 hover:bg-slate-50"
          onClick={onProfileClick}
        >
          <Avatar className="w-8 h-8">
            <AvatarImage src="" alt="User" />
            <AvatarFallback className="bg-emerald-100 text-emerald-700">
              <User className="w-4 h-4" />
            </AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium hidden sm:block">Profile</span>
        </Button>
        
        <Button
          onClick={onLoginClick}
          className="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium"
        >
          Login
        </Button>
      </div>
    </header>
  );
}