import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Droplet, Footprints, Moon, Plus, TrendingUp, Lightbulb, Check, Star, Shield, Heart, Trash2 } from "lucide-react";
import { TabType, HealthData, Medication, FoodItem } from "../types";

interface MainContentProps {
  activeTab: TabType;
  healthData: HealthData;
  updateHealthData: (updates: Partial<HealthData>) => void;
  addSymptom: (name: string) => void;
  addMedication: (med: Omit<Medication, "id">) => void;
  addFoodItem: (item: Omit<FoodItem, "id">) => void;
  deleteFoodItem: (id: number) => void;
}

export default function MainContent({ activeTab, healthData, updateHealthData, addSymptom, addMedication, addFoodItem, deleteFoodItem }: MainContentProps) {
  const [newSymptom, setNewSymptom] = useState("");
  const [newMed, setNewMed] = useState({ name: "", dosage: "", frequency: "" });
  const [newFood, setNewFood] = useState({ name: "", calories: "", protein: "", fat: "" });

  // Calculate Nutrition Totals
  const totalCalories = healthData.foodItems.reduce((sum, item) => sum + item.calories, 0);
  const totalProtein = healthData.foodItems.reduce((sum, item) => sum + item.protein, 0);
  const totalFat = healthData.foodItems.reduce((sum, item) => sum + item.fat, 0);

  const addWater = () => {
    updateHealthData({ water: healthData.water + 250 });
  };

  const updateSteps = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateHealthData({ steps: parseInt(e.target.value) || 0 });
  };

  const handleAddSymptom = () => {
    if (newSymptom.trim()) {
      addSymptom(newSymptom);
      setNewSymptom("");
    }
  };

  const handleAddMedication = () => {
    if (newMed.name && newMed.dosage) {
      addMedication({ ...newMed, status: "pending" });
      setNewMed({ name: "", dosage: "", frequency: "" });
    }
  };

  const toggleMedication = (id: number) => {
    const updatedMeds = healthData.medications.map((med) =>
      med.id === id ? { ...med, status: med.status === "taken" ? "pending" : "taken" } : med
    );
    updateHealthData({ medications: updatedMeds });
  };

  const handleAddFood = () => {
    if (newFood.name && newFood.calories) {
      addFoodItem({
        name: newFood.name,
        calories: parseFloat(newFood.calories) || 0,
        protein: parseFloat(newFood.protein) || 0,
        fat: parseFloat(newFood.fat) || 0,
      });
      setNewFood({ name: "", calories: "", protein: "", fat: "" });
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Welcome back!</h2>
              <p className="text-slate-600 mt-1">Here's your health overview for today.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-slate-200 hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                    <Droplet className="w-4 h-4 text-blue-500" />
                    Water Intake
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-800">{(healthData.water / 1000).toFixed(1)}L</div>
                  <p className="text-sm text-slate-500 mt-1">of {(healthData.waterGoal / 1000).toFixed(1)}L daily goal</p>
                  <div className="mt-3 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full transition-all duration-500" style={{ width: `${(healthData.water / healthData.waterGoal) * 100}%` }} />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-slate-200 hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                    <Footprints className="w-4 h-4 text-emerald-500" />
                    Daily Steps
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-800">{healthData.steps.toLocaleString()}</div>
                  <p className="text-sm text-slate-500 mt-1">of {healthData.stepsGoal.toLocaleString()} steps</p>
                  <div className="mt-3 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: `${(healthData.steps / healthData.stepsGoal) * 100}%` }} />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-slate-200 hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                    <Moon className="w-4 h-4 text-purple-500" />
                    Sleep
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-800">{healthData.sleep}h</div>
                  <p className="text-sm text-slate-500 mt-1">of {healthData.sleepGoal}h recommended</p>
                  <div className="mt-3 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 rounded-full transition-all duration-500" style={{ width: `${(healthData.sleep / healthData.sleepGoal) * 100}%` }} />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="flex gap-3 flex-wrap">
              <Button onClick={addWater} className="bg-blue-500 hover:bg-blue-600">
                <Plus className="w-4 h-4 mr-2" />
                Add 250ml Water
              </Button>
              <Button variant="outline" className="border-slate-300 text-slate-700 hover:bg-slate-50">
                <TrendingUp className="w-4 h-4 mr-2" />
                View Trends
              </Button>
            </div>

            <Card className="bg-amber-50 border-amber-200">
              <CardHeader>
                <CardTitle className="text-amber-800 flex items-center gap-2">
                  <Lightbulb className="w-5 h-5" />
                  Daily Health Tip
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-amber-900">
                  Drinking a glass of water before each meal can help with digestion and keep you hydrated throughout the day. Try it today!
                </p>
              </CardContent>
            </Card>
          </div>
        );

      case "water":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Water Tracking</h2>
              <p className="text-slate-600 mt-1">Monitor your daily hydration levels.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Today's Progress</CardTitle>
                  <CardDescription>{(healthData.water / 1000).toFixed(1)}L of {(healthData.waterGoal / 1000).toFixed(1)}L goal reached</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-center py-8">
                    <div className="relative w-48 h-48">
                      <div className="absolute inset-0 rounded-full border-8 border-slate-200" />
                      <div 
                        className="absolute inset-0 rounded-full border-8 border-blue-500 border-t-transparent border-l-transparent transition-all duration-500" 
                        style={{ transform: `rotate(${(healthData.water / healthData.waterGoal) * 360}deg)` }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <div className="text-4xl font-bold text-slate-800">{Math.round((healthData.water / healthData.waterGoal) * 100)}%</div>
                          <div className="text-sm text-slate-500">Complete</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Add</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button onClick={() => updateHealthData({ water: healthData.water + 250 })} className="w-full bg-blue-500 hover:bg-blue-600">
                    <Droplet className="w-4 h-4 mr-2" />
                    Add Glass (250ml)
                  </Button>
                  <Button onClick={() => updateHealthData({ water: healthData.water + 500 })} variant="outline" className="w-full border-blue-300 text-blue-700 hover:bg-blue-50">
                    <Droplet className="w-4 h-4 mr-2" />
                    Add Bottle (500ml)
                  </Button>
                  <Button onClick={() => updateHealthData({ water: 0 })} variant="outline" className="w-full border-slate-300 text-slate-700 hover:bg-slate-50">
                    Reset Day
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case "nutrition":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Nutrition Guide</h2>
              <p className="text-slate-600 mt-1">Track your meals and nutritional intake.</p>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-orange-200 bg-orange-50/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-orange-700 flex items-center gap-2">
                    <Star className="w-4 h-4 text-orange-500" />
                    Total Calories
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-800">{totalCalories.toLocaleString()}</div>
                  <p className="text-sm text-slate-500 mt-1">kcal consumed</p>
                </CardContent>
              </Card>

              <Card className="border-blue-200 bg-blue-50/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-blue-700 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-blue-500" />
                    Total Protein
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-800">{totalProtein.toFixed(1)}g</div>
                  <p className="text-sm text-slate-500 mt-1">consumed</p>
                </CardContent>
              </Card>

              <Card className="border-rose-200 bg-rose-50/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-rose-700 flex items-center gap-2">
                    <Heart className="w-4 h-4 text-rose-500" />
                    Total Fat
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-slate-800">{totalFat.toFixed(1)}g</div>
                  <p className="text-sm text-slate-500 mt-1">consumed</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Add Food Form */}
              <Card className="lg:col-span-1">
                <CardHeader>
                  <CardTitle>Add Food Item</CardTitle>
                  <CardDescription>Log what you ate</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="food-name">Food Name</Label>
                    <Input
                      id="food-name"
                      placeholder="e.g., Banana"
                      value={newFood.name}
                      onChange={(e) => setNewFood({ ...newFood, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="food-cal">Calories (kcal)</Label>
                    <Input
                      id="food-cal"
                      type="number"
                      placeholder="e.g., 105"
                      value={newFood.calories}
                      onChange={(e) => setNewFood({ ...newFood, calories: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="food-prot">Protein (g)</Label>
                      <Input
                        id="food-prot"
                        type="number"
                        placeholder="0"
                        value={newFood.protein}
                        onChange={(e) => setNewFood({ ...newFood, protein: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="food-fat">Fat (g)</Label>
                      <Input
                        id="food-fat"
                        type="number"
                        placeholder="0"
                        value={newFood.fat}
                        onChange={(e) => setNewFood({ ...newFood, fat: e.target.value })}
                      />
                    </div>
                  </div>
                  <Button onClick={handleAddFood} className="w-full bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add to Log
                  </Button>
                </CardContent>
              </Card>

              {/* Food List */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Today's Food Log</CardTitle>
                  <CardDescription>List of consumed items</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {healthData.foodItems.map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100 hover:border-slate-200 transition-colors">
                        <div className="flex-1">
                          <h4 className="font-medium text-slate-800">{item.name}</h4>
                          <div className="flex gap-4 mt-1 text-sm text-slate-600">
                            <span className="flex items-center gap-1"><Star className="w-3 h-3 text-orange-500" /> {item.calories} kcal</span>
                            <span className="flex items-center gap-1"><Shield className="w-3 h-3 text-blue-500" /> {item.protein}g</span>
                            <span className="flex items-center gap-1"><Heart className="w-3 h-3 text-rose-500" /> {item.fat}g</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteFoodItem(item.id)}
                          className="text-slate-400 hover:text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                    {healthData.foodItems.length === 0 && (
                      <p className="text-sm text-slate-500 text-center py-8">No food items logged yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case "symptoms":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Symptom Checker</h2>
              <p className="text-slate-600 mt-1">Log and track your symptoms over time.</p>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Log New Symptom</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter symptom name..."
                    value={newSymptom}
                    onChange={(e) => setNewSymptom(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleAddSymptom()}
                  />
                  <Button onClick={handleAddSymptom} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Symptoms</CardTitle>
                <CardDescription>Your logged symptoms</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {healthData.symptoms.map((symptom) => (
                    <div key={symptom.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-amber-500 rounded-full" />
                        <span className="text-sm text-slate-700">{symptom.name}</span>
                      </div>
                      <span className="text-xs text-slate-500">{symptom.date}</span>
                    </div>
                  ))}
                  {healthData.symptoms.length === 0 && (
                    <p className="text-sm text-slate-500 text-center py-4">No symptoms logged yet.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case "medications":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Medications</h2>
              <p className="text-slate-600 mt-1">Manage your medication schedule and reminders.</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Add New Medication</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <Label htmlFor="med-name">Medication Name</Label>
                  <Input
                    id="med-name"
                    placeholder="e.g., Aspirin"
                    value={newMed.name}
                    onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="med-dosage">Dosage</Label>
                  <Input
                    id="med-dosage"
                    placeholder="e.g., 100mg"
                    value={newMed.dosage}
                    onChange={(e) => setNewMed({ ...newMed, dosage: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="med-freq">Frequency</Label>
                  <Input
                    id="med-freq"
                    placeholder="e.g., Twice daily"
                    value={newMed.frequency}
                    onChange={(e) => setNewMed({ ...newMed, frequency: e.target.value })}
                  />
                </div>
                <Button onClick={handleAddMedication} className="w-full bg-emerald-600 hover:bg-emerald-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Medication
                </Button>
              </CardContent>
            </Card>

            <div className="space-y-4">
              {healthData.medications.map((med) => (
                <Card key={med.id} className={med.status === "taken" ? "border-emerald-200 bg-emerald-50/30" : ""}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{med.name}</span>
                      <Button
                        size="sm"
                        variant={med.status === "taken" ? "default" : "outline"}
                        onClick={() => toggleMedication(med.id)}
                        className={med.status === "taken" ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                      >
                        {med.status === "taken" ? <Check className="w-4 h-4 mr-1" /> : null}
                        {med.status === "taken" ? "Taken" : "Mark Taken"}
                      </Button>
                    </CardTitle>
                    <CardDescription>{med.dosage} • {med.frequency}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>
        );

      case "tips":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Health Tips</h2>
              <p className="text-slate-600 mt-1">Daily wellness advice and recommendations.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-blue-800">Stay Hydrated</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-blue-900 text-sm">
                    Aim to drink at least 8 glasses of water daily. Set reminders to help you stay on track.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-emerald-50 border-emerald-200">
                <CardHeader>
                  <CardTitle className="text-emerald-800">Move More</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-emerald-900 text-sm">
                    Take short walking breaks every hour. Even 5 minutes can boost your energy and focus.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-purple-50 border-purple-200">
                <CardHeader>
                  <CardTitle className="text-purple-800">Sleep Well</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-purple-900 text-sm">
                    Maintain a consistent sleep schedule. Aim for 7-9 hours of quality sleep each night.
                  </p>
                </CardContent>
              </Card>
              <Card className="bg-rose-50 border-rose-200">
                <CardHeader>
                  <CardTitle className="text-rose-800">Eat Balanced</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-rose-900 text-sm">
                    Include a variety of fruits, vegetables, whole grains, and lean proteins in your diet.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <main className="flex-1 p-6 overflow-auto">
      {renderContent()}
    </main>
  );
}