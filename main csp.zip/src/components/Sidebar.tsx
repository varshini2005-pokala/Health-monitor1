import { Home, Droplet, Book, ClipboardCheck, Pill, Lightbulb, Heart, X } from "lucide-react";
import { TabType } from "../types";
import { tabs } from "../utils/tabs";

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  onCloseMobile?: () => void;
}

const iconMap = {
  home: Home,
  water: Droplet,
  nutrition: Book,
  symptoms: ClipboardCheck,
  medications: Pill,
  tips: Lightbulb,
};

export default function Sidebar({ activeTab, onTabChange, onCloseMobile }: SidebarProps) {
  const handleTabClick = (tab: TabType) => {
    onTabChange(tab);
    // Close sidebar on mobile after tab selection
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  return (
    <aside className="w-64 bg-white min-h-screen flex flex-col">
      <div className="p-4 border-b border-slate-200 flex items-center justify-between">
        <h1 className="text-xl font-bold text-emerald-600 flex items-center gap-2">
          <Heart className="w-6 h-6" />
          Health Monitor
        </h1>
        <button
          onClick={onCloseMobile}
          className="md:hidden text-slate-400 hover:text-slate-600"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {tabs.map((tab) => {
          const Icon = iconMap[tab.id as keyof typeof iconMap];
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id as TabType)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? "bg-emerald-50 text-emerald-700 font-medium"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? "text-emerald-600" : "text-slate-400"}`} />
              <span className="text-sm">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-200">
        <div className="px-4 py-3 bg-slate-50 rounded-lg">
          <p className="text-xs text-slate-500 font-medium">Daily Progress</p>
          <div className="mt-2 h-2 bg-slate-200 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: "68%" }} />
          </div>
          <p className="text-xs text-slate-600 mt-1">68% complete</p>
        </div>
      </div>
    </aside>
  );
}