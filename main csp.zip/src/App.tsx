import { useState } from "react";
import Sidebar from "./components/Sidebar";
import MainContent from "./components/MainContent";
import Header from "./components/Header";
import LoginPage from "./components/LoginPage";
import { TabType, HealthData, FoodItem, Medication, UserProfile } from "./types";

const initialHealthData: HealthData = {
  water: 1800,
  waterGoal: 2000,
  steps: 7200,
  stepsGoal: 10000,
  sleep: 7,
  sleepGoal: 8,
  symptoms: [
    { id: 1, name: "Headache", date: "2 days ago" },
    { id: 2, name: "Fatigue", date: "3 days ago" },
  ],
  medications: [
    { id: 1, name: "Vitamin D", dosage: "1000 IU", frequency: "Once daily", status: "taken" },
    { id: 2, name: "Omega-3", dosage: "1000mg", frequency: "Once daily", status: "pending" },
  ],
  foodItems: [
    { id: 1, name: "Grilled Chicken Breast", calories: 165, protein: 31, fat: 3.6 },
    { id: 2, name: "Brown Rice (1 cup)", calories: 216, protein: 5, fat: 1.8 },
    { id: 3, name: "Avocado", calories: 160, protein: 2, fat: 15 },
  ],
};

const initialUserProfile: UserProfile = {
  name: "Alex Johnson",
  email: "alex.johnson@example.com",
  memberSince: "January 2024",
  location: "San Francisco, CA",
  bio: "Health enthusiast focused on balanced nutrition and daily fitness. Tracking progress to build better habits.",
};

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>("home");
  const [previousTab, setPreviousTab] = useState<TabType>("home");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>(initialUserProfile);
  const [healthData, setHealthData] = useState<HealthData>(initialHealthData);

  const handleTabChange = (tab: TabType) => {
    if (tab !== activeTab) {
      setPreviousTab(activeTab);
      setActiveTab(tab);
    }
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const handleProfileClick = () => {
    setPreviousTab(activeTab);
    setActiveTab("profile");
  };

  const handleBack = () => {
    setActiveTab(previousTab);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const updateHealthData = (updates: Partial<HealthData>) => {
    setHealthData((prev) => ({ ...prev, ...updates }));
  };

  const addSymptom = (name: string) => {
    const newSymptom = {
      id: Date.now(),
      name,
      date: "Just now",
    };
    updateHealthData({ symptoms: [newSymptom, ...healthData.symptoms] });
  };

  const addMedication = (med: Omit<Medication, "id">) => {
    const newMed = { ...med, id: Date.now() };
    updateHealthData({ medications: [...healthData.medications, newMed] });
  };

  const addFoodItem = (item: Omit<FoodItem, "id">) => {
    const newItem = { ...item, id: Date.now() };
    updateHealthData({ foodItems: [...healthData.foodItems, newItem] });
  };

  const deleteFoodItem = (id: number) => {
    updateHealthData({ foodItems: healthData.foodItems.filter((item) => item.id !== id) });
  };

  return (
    <div className="flex h-screen bg-slate-50">
      {showLogin && (
        <LoginPage onLogin={() => setShowLogin(false)} onClose={() => setShowLogin(false)} />
      )}

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-50 transition-all duration-300 ease-in-out bg-white border-r border-slate-200 flex flex-col ${
          sidebarOpen ? "w-64 translate-x-0" : "w-0 -translate-x-full md:translate-x-0 overflow-hidden"
        }`}
      >
        <Sidebar activeTab={activeTab} onTabChange={handleTabChange} onCloseMobile={() => setSidebarOpen(false)} />
      </aside>

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          onMenuClick={toggleSidebar}
          sidebarOpen={sidebarOpen}
          onLoginClick={() => setShowLogin(true)}
          onBack={handleBack}
          onProfileClick={handleProfileClick}
          activeTab={activeTab}
          userName={userProfile.name}
        />
        <MainContent
          activeTab={activeTab}
          healthData={healthData}
          updateHealthData={updateHealthData}
          addSymptom={addSymptom}
          addMedication={addMedication}
          addFoodItem={addFoodItem}
          deleteFoodItem={deleteFoodItem}
          userProfile={userProfile}
        />
      </div>
    </div>
  );
}