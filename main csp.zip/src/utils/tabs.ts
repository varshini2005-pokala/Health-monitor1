import { Tab } from "../types";

export const tabs: Tab[] = [
  { id: "home", label: "Home", icon: "Home" },
  { id: "water", label: "Water Tracking", icon: "Droplet" },
  { id: "nutrition", label: "Nutrition Guide", icon: "Book" },
  { id: "symptoms", label: "Symptom Checker", icon: "ClipboardCheck" },
  { id: "medications", label: "Medications", icon: "Pill" },
  { id: "tips", label: "Health Tips", icon: "Lightbulb" },
];