export type TabType = "home" | "water" | "nutrition" | "symptoms" | "medications" | "tips" | "profile";

export interface Tab {
  id: TabType;
  label: string;
  icon: string;
}

export interface Symptom {
  id: number;
  name: string;
  date: string;
}

export interface Medication {
  id: number;
  name: string;
  dosage: string;
  frequency: string;
  status: "taken" | "pending";
}

export interface FoodItem {
  id: number;
  name: string;
  calories: number;
  protein: number; // in grams
  fat: number; // in grams
}

export interface UserProfile {
  name: string;
  email: string;
  memberSince: string;
  location: string;
  bio: string;
}

export interface HealthData {
  water: number; // in ml
  waterGoal: number;
  steps: number;
  stepsGoal: number;
  sleep: number;
  sleepGoal: number;
  symptoms: Symptom[];
  medications: Medication[];
  foodItems: FoodItem[];
}